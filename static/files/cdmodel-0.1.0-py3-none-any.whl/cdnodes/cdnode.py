from abc import ABC, abstractmethod
import logging
from typing import Dict, Any

class CDNode(ABC):
    def __init__(self):
        logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    @abstractmethod
    def configure(self, params: Dict[str, Any]):
        super().configure(params)

    @abstractmethod
    def start(self):
        super().start()

    @abstractmethod
    def stop(self):
        super().stop()

    def log(self, message):
        pass


