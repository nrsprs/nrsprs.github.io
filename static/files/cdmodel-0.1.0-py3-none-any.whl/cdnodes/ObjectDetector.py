import logging
from abc import abstractmethod
from typing import Dict, Any
from .cdnode import CDNode
from cdmodel import Image
from cdmodel import ObjectDetectionState

class IObjectDetector(CDNode):
    def __init__(self):
        super().__init__()   # call base class constructor
        self.logger = logging.getLogger("ObjectDetector")

    def log(self, message):
        super().__init__()   # call base class constructor

    @abstractmethod
    def configure(self, parameters: Dict[str, Any]):
        super().configure()  # must be overridden by implementation class

    @abstractmethod
    def start(self):
        super().start()  # must be overridden by implementation class

    @abstractmethod
    def stop(self):
        super().stop()  # must be overridden by implementation class

    @abstractmethod
    def line(self, msg: Image):
        super().line(msg)  # must be overridden by implementation class

    def publish_detection_state(self, msg: ObjectDetectionState):
        pass
