import logging
from abc import abstractmethod
from typing import Dict, Any
from .cdnode import CDNode
from cdmodel import LineScannerCommand
from cdmodel import Image
from cdmodel import ObjectDetectionState

class ILineScanningCamera(CDNode):
    def __init__(self):
        super().__init__()   # call base class constructor
        self.logger = logging.getLogger("LineScanningCamera")

    def log(self, message):
        super().__init__()   # call base class constructor

    @abstractmethod
    def configure(self, parameters: Dict[str, Any]):
        super().configure()  # must be overridden by implementation class

    @abstractmethod
    def start(self):
        super().start()  # must be overridden by implementation class

    @abstractmethod
    def stop(self):
        super().stop()  # must be overridden by implementation class

    @abstractmethod
    def command(self, msg: LineScannerCommand):
        super().command(msg)  # must be overridden by implementation class

    def publish_image_out(self, msg: Image):
        pass

    def publish_detection_state(self, msg: ObjectDetectionState):
        pass
