import logging
from abc import abstractmethod
from typing import Dict, Any
from .cdnode import CDNode
from cdmodel import GoSignal
from cdmodel import Image
from cdmodel import ObjectDetectionState

class IObjectConfirmation(CDNode):
    def __init__(self):
        super().__init__()   # call base class constructor
        self.logger = logging.getLogger("ObjectConfirmation")

    def log(self, message):
        super().__init__()   # call base class constructor

    @abstractmethod
    def configure(self, parameters: Dict[str, Any]):
        super().configure()  # must be overridden by implementation class

    @abstractmethod
    def start(self):
        super().start()  # must be overridden by implementation class

    @abstractmethod
    def stop(self):
        super().stop()  # must be overridden by implementation class

    @abstractmethod
    def still_image(self, msg: Image):
        super().still_image(msg)  # must be overridden by implementation class

    @abstractmethod
    def garment_detection_state_changed(self, msg: ObjectDetectionState):
        super().garment_detection_state_changed(msg)  # must be overridden by implementation class

    def publish_object_confirmation(self, msg: GoSignal):
        pass
