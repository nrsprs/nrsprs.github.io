import logging
from abc import abstractmethod
from typing import Dict, Any
from .cdnode import CDNode
from cdmodel import CuttingInstructions
from cdmodel import LaserInstructions

class ICutSettingsCalculator(CDNode):
    def __init__(self):
        super().__init__()   # call base class constructor
        self.logger = logging.getLogger("CutSettingsCalculator")

    def log(self, message):
        super().__init__()   # call base class constructor

    @abstractmethod
    def configure(self, parameters: Dict[str, Any]):
        super().configure()  # must be overridden by implementation class

    @abstractmethod
    def start(self):
        super().start()  # must be overridden by implementation class

    @abstractmethod
    def stop(self):
        super().stop()  # must be overridden by implementation class

    @abstractmethod
    def cut_polygons(self, msg: CuttingInstructions):
        super().cut_polygons(msg)  # must be overridden by implementation class

    def publish_laser_instructions(self, msg: LaserInstructions):
        pass
