import logging
from abc import abstractmethod
from typing import Dict, Any
from .cdnode import CDNode
from cdmodel import CuttingInstructions
from cdmodel import Image
from cdmodel import ObjectDetectionState

class ICutPolygonGenerator(CDNode):
    def __init__(self):
        super().__init__()   # call base class constructor
        self.logger = logging.getLogger("CutPolygonGenerator")

    def log(self, message):
        super().__init__()   # call base class constructor

    @abstractmethod
    def configure(self, parameters: Dict[str, Any]):
        super().configure()  # must be overridden by implementation class

    @abstractmethod
    def start(self):
        super().start()  # must be overridden by implementation class

    @abstractmethod
    def stop(self):
        super().stop()  # must be overridden by implementation class

    @abstractmethod
    def image_rgb(self, msg: Image):
        super().image_rgb(msg)  # must be overridden by implementation class

    @abstractmethod
    def image_ir(self, msg: Image):
        super().image_ir(msg)  # must be overridden by implementation class

    @abstractmethod
    def image_still(self, msg: Image):
        super().image_still(msg)  # must be overridden by implementation class

    @abstractmethod
    def garmet_detection_state(self, msg: ObjectDetectionState):
        super().garmet_detection_state(msg)  # must be overridden by implementation class

    def publish_cut_polygons(self, msg: CuttingInstructions):
        pass
