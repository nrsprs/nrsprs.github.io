import logging
from abc import abstractmethod
from typing import Dict, Any
from .cdnode import CDNode
from cdmodel import Image
from cdmodel import StillCameraCommand

class ISnapshotCamera(CDNode):
    def __init__(self):
        super().__init__()   # call base class constructor
        self.logger = logging.getLogger("SnapshotCamera")

    def log(self, message):
        super().__init__()   # call base class constructor

    @abstractmethod
    def configure(self, parameters: Dict[str, Any]):
        super().configure()  # must be overridden by implementation class

    @abstractmethod
    def start(self):
        super().start()  # must be overridden by implementation class

    @abstractmethod
    def stop(self):
        super().stop()  # must be overridden by implementation class

    @abstractmethod
    def command(self, msg: StillCameraCommand):
        super().command(msg)  # must be overridden by implementation class

    def publish_image_out(self, msg: Image):
        pass
